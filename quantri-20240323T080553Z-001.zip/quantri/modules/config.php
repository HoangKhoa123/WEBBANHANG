<?php
$username = "root";
$password ="";
$server ="localhost";
$dbname = "thuhuongfpt";
$conn = new mysqli($server,$username,$password,$dbname) or die("Không thể connert ".mysqli_error($conn));

?>